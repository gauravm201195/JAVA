package com.capgemini.employee.exception;

public class EmployeeManagementException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8531318318783803360L;

	public EmployeeManagementException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeManagementException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
