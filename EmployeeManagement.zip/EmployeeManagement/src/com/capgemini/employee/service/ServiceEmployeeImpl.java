package com.capgemini.employee.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.dao.EmployeeDAOImpl;
import com.capgemini.employee.dao.IEmployeDAO;
import com.capgemini.employee.exception.EmployeeManagementException;



public class ServiceEmployeeImpl implements IServiceEmployee {

	private IEmployeDAO employeeDAO;
	
	public ServiceEmployeeImpl() {
		employeeDAO = new EmployeeDAOImpl();
	}
	
	@Override
	public boolean insertEmployee(EmployeeBean employeeBean) throws EmployeeManagementException {
		boolean isItInserted = false;
		isItInserted = employeeDAO.insertEmployee(employeeBean);
		return isItInserted;
	}

	@Override
	public boolean deleteEmployee(String name)throws EmployeeManagementException {
		boolean isDeleted = false;
		 isDeleted = employeeDAO.deleteEmployee(name);
		return isDeleted;
	
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeeManagementException {
		List<EmployeeBean> employeeList = employeeDAO.viewAll();
		return employeeList;		
	}

	@Override
	public boolean updateEmployee(int id, String designation)throws EmployeeManagementException {
		boolean isUpdated = false;
		isUpdated = employeeDAO.updateEmployee(id, designation);
		return isUpdated;
	}
	public boolean isValidCName(String cname) throws EmployeeManagementException{
		boolean isValid = false;
		
		String pattern ="[A-Z]{1}[A-Za-z]{1,19}";
		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(cname);
		isValid = matcher.matches();
		
		if(!isValid){
			throw new EmployeeManagementException("Invalid name");
		}
		
		return isValid;
	}
}