package com.capgemini.employee.service;

import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeManagementException;

public interface IServiceEmployee {
	
	public boolean insertEmployee(EmployeeBean employeBean) throws EmployeeManagementException;
	
	public boolean deleteEmployee(String name) throws EmployeeManagementException;
/*	
ASK THIS THING TO SIR WHY IS IT NOT INCLUDED*/
	public boolean updateEmployee(final int id,final String designation) throws EmployeeManagementException;
	
	public List<EmployeeBean> viewAll() throws EmployeeManagementException;

}
