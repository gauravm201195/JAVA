package com.capgemini.employee.pi;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeManagementException;
import com.capgemini.employee.service.ServiceEmployeeImpl;


public class EmployeeManagementMain {
	private static Logger logger=Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		
		boolean isInProcess = true;
		boolean isValid = false;
		
		byte choice = 0;
		
		String cname = null;
		float salary = 0;
		String hiredate = null;
		String department = null;
		String designation = null;
		
		int Id = 0;
		
		ServiceEmployeeImpl serviceEmployee = new ServiceEmployeeImpl();
		
		EmployeeBean employeeBean = null;
		
		List<EmployeeBean>employeeList = null;
		
		Scanner scan = new Scanner(System.in);
		
		while(isInProcess){
			
			System.out.println("1. Insert Employee.");
			System.out.println("2. Update Employee.");
			System.out.println("3. Delete Employee details.");
			System.out.println("4. View Employee.");
			System.out.println("0. Exit");
			
choice = Byte.parseByte(scan.nextLine());
			
			switch (choice){
			case 1://Insert Employee Details
				isValid = false;
				while(!isValid){

					try{
						System.out.println("Enter Employee name: ");
						cname= scan.nextLine();
						

						isValid = serviceEmployee.isValidCName(cname);
						
					}catch(EmployeeManagementException eme){
						logger.error("Invalid name: " +cname);
						System.err.println("Invalid name: " +cname);
						isValid = false;
					}
					
				}
				System.out.println("Enter Salary: ");
				salary= Float.parseFloat(scan.nextLine());
				
				//Date Enter using date formatter
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				System.out.println("Enter hiredate: ");
				hiredate= scan.nextLine();
				TemporalAccessor ta = dtf.parse(hiredate);
				LocalDate localdate = LocalDate.from(ta);
				java.sql.Date translatedDate = java.sql.Date.valueOf(localdate);
				
				System.out.println("Enter Department: ");
				department= scan.nextLine();
				System.out.println("Enter Designation: ");
				designation= scan.nextLine();	
				
				employeeBean = new EmployeeBean(cname, salary, translatedDate, department, designation);
				System.out.println(employeeBean);
				try{
					serviceEmployee.insertEmployee(employeeBean);
				}catch(EmployeeManagementException e){
					logger.error(e.getMessage());
				}
				break;
			case 2://Update Employee
				System.out.println("Enter Employee ID: ");
				Id = scan.nextInt();
					scan.nextLine();
				System.out.println("Enter Designation: ");
				designation = scan.nextLine();
						
				try{
					boolean isUpdated = serviceEmployee.updateEmployee(Id, designation);
					if(isUpdated){
						System.out.println("Employee record updated successfully");
					}
				}catch(EmployeeManagementException e){
					logger.error(e.getMessage());
				}
				
				break;
			case 3://Delete Employee
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter Employee name ");
						cname= scan.nextLine();
						
						isValid = serviceEmployee.isValidCName(cname);
						
					}catch(EmployeeManagementException eme){
						logger.error("Invalid Employee name: " +cname);
						System.err.println("Invalid Employee name: " +cname);
						isValid = false;
					}
				}
				
				try{
					boolean isDeleted = serviceEmployee.deleteEmployee(cname);
					if(isDeleted){
						System.out.println("Employee record deleted successfully");
					}
				}catch(EmployeeManagementException e){
					logger.error(e.getMessage());
				}
				break;
			case 4://View All Employee Details
					try{
					employeeList = serviceEmployee.viewAll();
						for (EmployeeBean employeeBean2 : employeeList){
							System.out.println(employeeBean2);
						}
						System.out.println("====================================================================");
					}catch(EmployeeManagementException e){
						logger.error(e.getMessage());
					}
				break;
			case 0:
				isInProcess = false;
				break;
			default:
				System.out.println("Invalid Input");
				logger.error("Invalid Input: " +choice);
				System.err.println("Invalid Input: " +choice);
				break;
				
			}
		}
		scan.close();
	}

}
