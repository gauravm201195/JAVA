package com.capgemini.employee.dao;

import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeManagementException;




public interface IEmployeDAO {
	public boolean insertEmployee(EmployeeBean employeeBean) throws EmployeeManagementException;
	
	public boolean deleteEmployee(final String name) throws EmployeeManagementException;
	
	public boolean updateEmployee(final int id,final String designation) throws EmployeeManagementException;
	
	public List<EmployeeBean> viewAll() throws EmployeeManagementException;
	

}
