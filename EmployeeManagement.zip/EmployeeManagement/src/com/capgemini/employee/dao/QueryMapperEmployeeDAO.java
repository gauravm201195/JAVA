package com.capgemini.employee.dao;

public interface QueryMapperEmployeeDAO {
	
	public static final  String INSERT_EMPLOYEE = "INSERT INTO employees VALUES(id_seq.NEXTVAL,?,?,?,?,?)";
	
	public static final  String UPDATE_EMPLOYEE = "UPDATE employees SET designation = ? WHERE id= ?";
	
	public static final  String DELETE_EMPLOYEE = "DELETE FROM employees WHERE name=?";
	
	public static final String VIEW_EMPLOYEE = "SELECT id, name, salary, hiredate, department, designation FROM employees";
}
