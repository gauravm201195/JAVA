package com.capgemini.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeManagementException;
import com.capgemini.employee.util.DBConnection;


public class EmployeeDAOImpl implements IEmployeDAO {

	@Override
	public boolean insertEmployee(EmployeeBean employeeBean) throws EmployeeManagementException {
		int records =0;
		boolean isInserted = false;
		try(Connection connEmployee =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connEmployee.prepareStatement(QueryMapperEmployeeDAO.INSERT_EMPLOYEE);
				){
			preparedStatement.setString(1, employeeBean.getName());
			preparedStatement.setFloat(2, employeeBean.getSalary());
			preparedStatement.setDate(3, employeeBean.getHiredate());
			preparedStatement.setString(4, employeeBean.getDepartment());
			preparedStatement.setString(5, employeeBean.getDesignation());
			
			records = preparedStatement.executeUpdate();
			if(records > 0){
				isInserted = true;
			}
		}catch(SQLException sqlEx){
			throw new EmployeeManagementException(sqlEx.getMessage());
		}
	
			return isInserted;
	}

	@Override
	public boolean deleteEmployee(String name)	throws EmployeeManagementException {
		int records =0;
		boolean isDeleted = false;
		try(Connection connEmployee =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connEmployee.prepareStatement(QueryMapperEmployeeDAO.DELETE_EMPLOYEE);
				){
			preparedStatement.setString(1, name);
			
			
			records = preparedStatement.executeUpdate();
			if(records > 0){
				isDeleted = true;
			}
		}catch(SQLException sqlEx){
			throw new EmployeeManagementException(sqlEx.getMessage());
		}
	
			return isDeleted;	
	}

	@Override
	public boolean updateEmployee(int id, String designation)throws EmployeeManagementException {
		int records =0;
		boolean isUpdated = false;
		try(Connection connEmployee =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connEmployee.prepareStatement(QueryMapperEmployeeDAO.UPDATE_EMPLOYEE);
				){
			preparedStatement.setString(1, designation);
			preparedStatement.setInt(2, id);
			
			
			records = preparedStatement.executeUpdate();
			if(records > 0){
				isUpdated = true;
			}
		}catch(SQLException sqlEx){
			throw new EmployeeManagementException(sqlEx.getMessage());
		}
	
			return isUpdated;	
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeeManagementException {
		List<EmployeeBean>employeeList = new ArrayList<EmployeeBean>();
		
		try(Connection connEmployee = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connEmployee.prepareStatement(QueryMapperEmployeeDAO.VIEW_EMPLOYEE);
				ResultSet rsEmployee = preparedStatement.executeQuery();
				){
			while(rsEmployee.next()){
				EmployeeBean employee = new EmployeeBean();
				
				employee.setId(rsEmployee.getInt("id"));
				employee.setName(rsEmployee.getString("name"));
				employee.setSalary(rsEmployee.getFloat("salary"));
				employee.setHiredate(rsEmployee.getDate("hiredate"));
				employee.setDepartment(rsEmployee.getString("department"));
				employee.setDesignation(rsEmployee.getString("designation"));
				
				employeeList.add(employee);
			}
			
			if(employeeList.size()==0){
				throw new EmployeeManagementException("No records found.");
			}
		}catch(SQLException sqlEx){
			throw new EmployeeManagementException(sqlEx.getMessage());
		}
		return employeeList;
	}

}

