create sequence id_seq start with 1000;

create table employeeDetails(
	id number(7),
	name varchar2(20),
	salary number(7,2),
	hiredate date,
	Department varchar2(20),
	Designation varchar2(20),
	primary key(id)
);

select id_seq.nextVal from dual

select * from employeeDetails;


