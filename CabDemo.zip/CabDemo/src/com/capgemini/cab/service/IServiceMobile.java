package com.capgemini.cab.service;

import java.util.List;

import com.capgemini.cab.bean.CabCustomerBean;
import com.capgemini.cab.exception.CabException;

public interface IServiceMobile {

	public List<CabCustomerBean>viewAll() throws CabException;
	
	public boolean deleteMobile(int mobileId)
	throws CabException;
	
	public List<CabCustomerBean>search(float minPrice,float maxPrice)
	throws CabException;
}
