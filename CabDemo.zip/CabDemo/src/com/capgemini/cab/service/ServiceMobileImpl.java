package com.capgemini.cab.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.cab.bean.CabCustomerBean;
import com.capgemini.cab.dao.ICustomerDAO;
import com.capgemini.cab.dao.IPurchaseDetailsDAO;
import com.capgemini.cab.dao.MobileDAOImpl;
import com.capgemini.cab.dao.PurchaseDetailsDAOImpl;
import com.capgemini.cab.exception.CabException;

public class ServiceMobileImpl implements IServiceMobile {

	private ICustomerDAO mobileDAO;
	
	public ServiceMobileImpl(){
		mobileDAO=new MobileDAOImpl();
	}
	@Override
	public List<CabCustomerBean> viewAll() throws CabException {
		
		List<CabCustomerBean> mobileList=mobileDAO.viewAll();
		return mobileList;
		
	
	}

	@Override
	public boolean deleteMobile(int mobileId) throws CabException {
		IPurchaseDetailsDAO purchaseDetailsDAO=new PurchaseDetailsDAOImpl();
		boolean isPurchaseDeleted=purchaseDetailsDAO.deletePurchaseDetails(mobileId);
		boolean isDeleted=mobileDAO.deleteMobile(mobileId);
		return (isDeleted && isPurchaseDeleted);
	}

	@Override
	public List<CabCustomerBean> search(float minPrice, float maxPrice)
			throws CabException {
		List<CabCustomerBean> mobileList=mobileDAO.search(minPrice,maxPrice);
		return mobileList;
	}
	
	public boolean isValidMobileId(int mobileId) throws CabException{
		boolean isValid=false;
		
		String mobile=Integer.toString(mobileId);
		String pattern="[\\d]{4}";
		
		isValid=Pattern.matches(mobile,pattern);
		if(!isValid){
			throw new CabException("Mobileid should be 4 digits long");
		}
		return isValid;
	}

}
