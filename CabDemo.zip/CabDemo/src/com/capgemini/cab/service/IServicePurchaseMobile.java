package com.capgemini.cab.service;

import com.capgemini.cab.bean.CabBean;
import com.capgemini.cab.exception.CabException;

public interface IServicePurchaseMobile {

	public boolean insertPurchaseDetails(CabBean purchaseDetailsBean)
	throws CabException;
	
	
}
