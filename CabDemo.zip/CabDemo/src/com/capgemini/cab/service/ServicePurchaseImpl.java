package com.capgemini.cab.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.cab.bean.CabBean;
import com.capgemini.cab.dao.ICustomerDAO;
import com.capgemini.cab.dao.IPurchaseDetailsDAO;
import com.capgemini.cab.dao.MobileDAOImpl;
import com.capgemini.cab.dao.PurchaseDetailsDAOImpl;
import com.capgemini.cab.exception.CabException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(CabBean purchaseDetailsBean)
			throws CabException {
		
		int mobileQuantity=0;
		boolean isItInserted=false;
		boolean isUpdated=false;
		
		IPurchaseDetailsDAO purchaseDetailsDAO=new PurchaseDetailsDAOImpl();
		ICustomerDAO mobileDAO=new MobileDAOImpl();
		
		mobileQuantity=mobileDAO.getQuantity(purchaseDetailsBean.getMobileId());
		
		if(mobileQuantity>0){
			isItInserted=purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
			mobileQuantity--;
			isUpdated=mobileDAO.updateMobile(purchaseDetailsBean.getMobileId(),mobileQuantity);
		}
		
			return (isItInserted && isUpdated);	
		
	}

	public boolean isValidCName(String cname) throws CabException{
		boolean isValid=false;
		
		String pattern="[A-Z]{1}[A-Za-z]{1,19}";
		Pattern ptn=Pattern.compile(pattern);
		Matcher matcher=ptn.matcher(cname);
		isValid=matcher.matches();
		
		if(!isValid){
			throw new CabException("Invalid Name");
		}
		return isValid;
	}
	
	public boolean isValidPhoneNo(String phoneNo) throws CabException{
		boolean isValid=false;
		
		String pattern="[\\d]{10}";
		Pattern ptn=Pattern.compile(pattern);
		Matcher matcher=ptn.matcher(phoneNo);
		isValid=matcher.matches();
		//isValid=Pattern.matches(phoneNo,pattern);
		if(!isValid){
			throw new CabException("Phone no. must be 10 digits long");
		}
		return isValid;
	}
	
	public boolean isValidMail(String mail) throws CabException{
		boolean isValid=false;
		
		String pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";
		Pattern ptn=Pattern.compile(pattern);
		Matcher matcher=ptn.matcher(mail);
		isValid=matcher.matches();
		//isValid=Pattern.matches(mail,pattern);
		if(!isValid){
			throw new CabException("Invalid Mailid");
		}
		return isValid;
	}
	
	public boolean isValidMobileId(int mobileId) throws CabException{
		boolean isValid=false;
		
		String mobile=Integer.toString(mobileId);
		String pattern="[\\d]{4}";
		Pattern ptn=Pattern.compile(pattern);
		Matcher matcher=ptn.matcher(mobile);
		isValid=matcher.matches();
		//isValid=Pattern.matches(mobile,pattern);
		if(!isValid){
			throw new CabException("Mobileid should be 4 digits long");
		}
		return isValid;
	}
}
