package com.capgemini.cab.dao;

import com.capgemini.cab.bean.CabCustomerBean;
import com.capgemini.cab.exception.CabException;

public interface ICustomerDAO {

	public boolean insertCustomer(final CabCustomerBean customerBean)
	throws CabException;
	
	public int viewCabs(String pin)throws CabException;
	
	public int getID()
	throws CabException;
}
