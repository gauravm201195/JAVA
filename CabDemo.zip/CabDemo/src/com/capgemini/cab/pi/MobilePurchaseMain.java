package com.capgemini.cab.pi;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.cab.bean.CabCustomerBean;
import com.capgemini.cab.bean.CabBean;
import com.capgemini.cab.exception.CabException;
import com.capgemini.cab.service.ServiceMobileImpl;
import com.capgemini.cab.service.ServicePurchaseImpl;

public class MobilePurchaseMain {

	private static Logger logger=Logger.getRootLogger(); 
	public static void main(String[] args) {
		/*PurchaseDetailsBean pdb=new PurchaseDetailsBean(1,"abc","abc@ab.com","99888",LocalDate.now(),1002);
		
		IServicePurchaseMobile isp=new ServicePurchaseImpl();
		
		try{
			boolean isInserted=isp.insertPurchaseDetails(pdb);
			if(isInserted){
				System.out.println("Record inserted successfully");
			}
		}catch(MobilePurchaseException mpe){
			System.out.println(mpe.getMessage());
		}*/
		PropertyConfigurator.configure("resources/log4j.prperties");
		
		boolean isInProcess=true;
		boolean isValid=false;
		byte choice=0;
		String cname=null;
		String mailId=null;
		String phoneNo=null;
		int mobileId=0;
		CabBean purchaseDetailsBean=null;
		
		ServiceMobileImpl serviceMobile=new ServiceMobileImpl();
		ServicePurchaseImpl servicePurchaseMobile=new ServicePurchaseImpl();
		
		List<CabCustomerBean>mobileList=null;
		Scanner scInput=new Scanner(System.in);
		
		while(isInProcess){
			System.out.println("1) Insert Mobile Purchase");
			System.out.println("2) View all mobiles");
			System.out.println("3) Delete mobile details");
			System.out.println("4) Search mobiles for a range");
			System.out.println("0) Exit");
			
			choice=Byte.parseByte(scInput.nextLine());
			
			switch(choice){
			case 1: 
				
				while(!isValid){
					try{
						System.out.println("Enter customer name:");
						cname=scInput.nextLine();
						
						isValid=servicePurchaseMobile.isValidCName(cname);
							
					}catch(CabException mpe){
						logger.error("Invalid name:"+ cname);
						System.err.println("Invalid name:"+cname);
						isValid=false;
				}
				
			}
				
				isValid=false;
				while(!isValid){
					try{
						System.out.println("Enter mail id:");
						mailId=scInput.nextLine();
						
						isValid=servicePurchaseMobile.isValidMail(mailId);
							
					}catch(CabException mpe){
						logger.error("Invalid mail id:"+ mailId);
						System.err.println("Invalid mail id:"+mailId);
						isValid=false;
				}
				
			}
				isValid=false;
				while(!isValid){
					try{
						System.out.println("Enter phone no:");
						phoneNo=scInput.nextLine();
						
						isValid=servicePurchaseMobile.isValidPhoneNo(phoneNo);
							
					}catch(CabException mpe){
						logger.error("Invalid phone no:"+ phoneNo);
						System.err.println("Invalid phone no:"+phoneNo);
						isValid=false;
				}
				
			}
				isValid=false;
				while(!isValid){
					try{
						System.out.println("Enter mobile id:");
					    mobileId=Integer.parseInt(scInput.nextLine());
						
						isValid=servicePurchaseMobile.isValidMobileId(mobileId);
							
					}catch(CabException mpe){
						logger.error("Invalid mobile ID:"+ mobileId);
						System.err.println("Invalid mobile id:"+mobileId);
						isValid=false;
				}
				
			}
				purchaseDetailsBean=new CabBean(cname,mailId,phoneNo,mobileId);
				try{
					servicePurchaseMobile.insertPurchaseDetails(purchaseDetailsBean);
				}catch(CabException e){
					logger.error(e.getMessage());
				}
				
				break;
			case 2:
			try{
				mobileList=serviceMobile.viewAll();
				for(CabCustomerBean mobileBean : mobileList){
					System.out.println(mobileBean);
				}
				System.out.println("=============================");
		    }catch(CabException e){
			logger.error(e.getMessage());
		}
		   break;
			case 3:
				isValid=false;
				
				while(!isValid){
					try{
						System.out.println("Enter mobile id:");
					    mobileId=Integer.parseInt(scInput.nextLine());
						
						isValid=servicePurchaseMobile.isValidMobileId(mobileId);
							
					}catch(CabException mpe){
						logger.error("Invalid mobile ID:"+ mobileId);
						isValid=false;
				}
				
			}
				try{
					boolean isDeleted=serviceMobile.deleteMobile(mobileId);
					if(isDeleted){
						System.out.println("Mobile record deleted successfully");
					}
				}catch(CabException e){
					logger.error(e.getMessage());
				}
				break;
			case 4:
				float minPrice=0;
				float maxPrice=0;
				
				System.out.println("Enter minimum price:");
				minPrice=Float.parseFloat(scInput.nextLine());
				
				System.out.println("Enter maximum price:");
				maxPrice=Float.parseFloat(scInput.nextLine());
				
				try{
				mobileList=serviceMobile.search(minPrice,maxPrice);
				
				for(CabCustomerBean mobileBean : mobileList){
					System.out.println(mobileBean);
				}
				System.out.println("===============================");
				}catch(CabException e){
		        logger.error(e.getMessage());
	            }
				break;
			case 0:
				isInProcess=false;
				break;
			default:
				System.out.println("Invalid input");
				logger.error("Invalid input:"+choice);
				System.err.println("Invalid input:"+choice);
				break;
					
				

    }
  }
		scInput.close();
}
}