package com.capgemini.cab.bean;

import java.time.LocalDate;

public class CabCustomerBean {

	private int customerid;
	private String name;
	private String address;
	private String pin;
	private String phoneNo;
	private LocalDate regDate;
		
	public CabCustomerBean() {
		super();
	}

	public CabCustomerBean(String name, String address,
			String pin, String phoneNo, LocalDate regDate) {
		super();
		
		this.name = name;
		this.address = address;
		this.pin = pin;
		this.phoneNo = phoneNo;
		this.regDate = regDate;
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public LocalDate getRegDate() {
		return regDate;
	}

	public void setRegDate(LocalDate regDate) {
		this.regDate = regDate;
	}

	@Override
	public String toString() {
		return "CabCustomerBean [customerid=" + customerid + ", name=" + name
				+ ", address=" + address + ", pin=" + pin + ", phoneNo="
				+ phoneNo + ", regDate=" + regDate + "]";
	}

	
	
}
