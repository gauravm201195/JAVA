package com.capgemini.mobpur.test;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mobpur.bean.PurchaseDetailsBean;
import com.capgemini.mobpur.exception.MobilePurchaseException;
import com.capgemini.mobpur.service.IServicePurchaseMobile;
import com.capgemini.mobpur.service.ServicePurchaseImpl;

public class ServicePurchaseImplTest {

	private PurchaseDetailsBean purchaseDetailsBean;
	@Before
	public void setUp() throws Exception {
		purchaseDetailsBean=new PurchaseDetailsBean("abc","abc@ab.com","99888",1002);
	}

	@After
	public void tearDown() throws Exception {
		purchaseDetailsBean=null;
	}

	@Test
	public final void testInsertPurchaseDetails() {
		IServicePurchaseMobile servicePurchaseMobile=new ServicePurchaseImpl();
		try{
		assertTrue(servicePurchaseMobile.insertPurchaseDetails(purchaseDetailsBean));
		}catch (MobilePurchaseException e){
			e.printStackTrace();
		}
	}

}
