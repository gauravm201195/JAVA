package com.capgemini.mobpur.dao;

import com.capgemini.mobpur.bean.PurchaseDetailsBean;
import com.capgemini.mobpur.exception.MobilePurchaseException;

public interface IPurchaseDetailsDAO {

	public boolean insertPurchase(final PurchaseDetailsBean purchaseDetailsBean)
	throws MobilePurchaseException;
	
	public boolean deletePurchaseDetails(final int mobileId)
	throws MobilePurchaseException;
}
