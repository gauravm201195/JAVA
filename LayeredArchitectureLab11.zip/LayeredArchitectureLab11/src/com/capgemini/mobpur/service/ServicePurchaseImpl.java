package com.capgemini.mobpur.service;

import com.capgemini.mobpur.bean.PurchaseDetailsBean;
import com.capgemini.mobpur.dao.IMobileDAO;
import com.capgemini.mobpur.dao.IPurchaseDetailsDAO;
import com.capgemini.mobpur.dao.MobileDAOImpl;
import com.capgemini.mobpur.dao.PurchaseDetailsDAOImpl;
import com.capgemini.mobpur.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException {
		
		int mobileQuantity=0;
		boolean isItInserted=false;
		boolean isUpdated=false;
		
		IPurchaseDetailsDAO purchaseDetailsDAO=new PurchaseDetailsDAOImpl();
		IMobileDAO mobileDAO=new MobileDAOImpl();
		
		mobileQuantity=mobileDAO.getQuantity(purchaseDetailsBean.getMobileId());
		
		if(mobileQuantity>0){
			isItInserted=purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
			mobileQuantity--;
			isUpdated=mobileDAO.updateMobile(purchaseDetailsBean.getMobileId(),mobileQuantity);
		}
		
			return (isItInserted && isUpdated);	
		
	}

}
