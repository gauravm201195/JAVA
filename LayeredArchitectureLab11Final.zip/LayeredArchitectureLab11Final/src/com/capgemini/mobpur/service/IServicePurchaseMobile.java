package com.capgemini.mobpur.service;

import com.capgemini.mobpur.bean.PurchaseDetailsBean;
import com.capgemini.mobpur.exception.MobilePurchaseException;

public interface IServicePurchaseMobile {

	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
	throws MobilePurchaseException;
	
	
}
