package com.capgemini.mobpur.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.mobpur.bean.MobileBean;
import com.capgemini.mobpur.dao.IMobileDAO;
import com.capgemini.mobpur.dao.IPurchaseDetailsDAO;
import com.capgemini.mobpur.dao.MobileDAOImpl;
import com.capgemini.mobpur.dao.PurchaseDetailsDAOImpl;
import com.capgemini.mobpur.exception.MobilePurchaseException;

public class ServiceMobileImpl implements IServiceMobile {

	private IMobileDAO mobileDAO;
	
	public ServiceMobileImpl(){
		mobileDAO=new MobileDAOImpl();
	}
	@Override
	public List<MobileBean> viewAll() throws MobilePurchaseException {
		
		List<MobileBean> mobileList=mobileDAO.viewAll();
		return mobileList;
		
	
	}

	@Override
	public boolean deleteMobile(int mobileId) throws MobilePurchaseException {
		IPurchaseDetailsDAO purchaseDetailsDAO=new PurchaseDetailsDAOImpl();
		boolean isPurchaseDeleted=purchaseDetailsDAO.deletePurchaseDetails(mobileId);
		boolean isDeleted=mobileDAO.deleteMobile(mobileId);
		return (isDeleted && isPurchaseDeleted);
	}

	@Override
	public List<MobileBean> search(float minPrice, float maxPrice)
			throws MobilePurchaseException {
		List<MobileBean> mobileList=mobileDAO.search(minPrice,maxPrice);
		return mobileList;
	}
	
	public boolean isValidMobileId(int mobileId) throws MobilePurchaseException{
		boolean isValid=false;
		
		String mobile=Integer.toString(mobileId);
		String pattern="[\\d]{4}";
		
		isValid=Pattern.matches(mobile,pattern);
		if(!isValid){
			throw new MobilePurchaseException("Mobileid should be 4 digits long");
		}
		return isValid;
	}

}
