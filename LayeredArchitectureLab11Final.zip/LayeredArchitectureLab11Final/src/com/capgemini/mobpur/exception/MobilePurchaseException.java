package com.capgemini.mobpur.exception;

public class MobilePurchaseException extends Exception {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 2333507435654752766L;

	public MobilePurchaseException(){
		super();
	}
	
	public MobilePurchaseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
